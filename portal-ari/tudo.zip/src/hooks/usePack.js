import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

// Conteúdo do Pack (aulão, questões, lives). A RLS só devolve linhas se o pack do aluno
// estiver dentro do prazo (ou se ele for assinante/admin) — conferido pelo relógio do banco.
export function usePackItens(turmaId) {
  const [itens, setItens] = useState([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState(null);

  const carregar = useCallback(async () => {
    setLoading(true);
    let query = supabase
      .from('pack_itens')
      .select('id, tipo, titulo, descricao, video_url, link_url, data_hora, duracao_min, turma_id, ordem')
      .eq('ativo', true)
      .order('ordem', { ascending: true })
      .order('data_hora', { ascending: true, nullsFirst: false });

    // Itens sem turma valem para todos; os demais, só para a turma do aluno.
    if (turmaId) query = query.or(`turma_id.is.null,turma_id.eq.${turmaId}`);
    else query = query.is('turma_id', null);

    const { data, error } = await query;
    if (error) setErro(error);
    else setErro(null);
    setItens(data ?? []);
    setLoading(false);
  }, [turmaId]);

  useEffect(() => {
    carregar();
  }, [carregar]);

  return {
    aulas: itens.filter((i) => i.tipo === 'aulao'),
    questoes: itens.filter((i) => i.tipo === 'questoes'),
    lives: itens.filter((i) => i.tipo === 'live'),
    loading,
    erro,
    recarregar: carregar,
  };
}

// Contador regressivo até `alvoMs`. Atualiza a cada segundo.
export function useRestante(alvoMs) {
  const [agora, setAgora] = useState(() => Date.now());

  useEffect(() => {
    if (!alvoMs) return undefined;
    const id = setInterval(() => setAgora(Date.now()), 1000);
    return () => clearInterval(id);
  }, [alvoMs]);

  return alvoMs ? Math.max(0, alvoMs - agora) : 0;
}
