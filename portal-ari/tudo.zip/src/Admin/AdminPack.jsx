import React, { useCallback, useEffect, useState } from 'react';
import {
  Plus, Pencil, Trash2, Loader2, X, PlayCircle, FileText, Radio, Eye, EyeOff, Package, Receipt,
} from 'lucide-react';
import AdminSidebar from './AdminSidebar';
import { supabase } from '../lib/supabaseClient';

const TIPOS = {
  aulao: { label: 'Aulão', icon: PlayCircle },
  questoes: { label: 'Questões', icon: FileText },
  live: { label: 'Live', icon: Radio },
};

const FORM_VAZIO = {
  tipo: 'aulao',
  titulo: '',
  descricao: '',
  video_url: '',
  link_url: '',
  data_hora: '',
  duracao_min: '',
  turma_id: '',
  ordem: 0,
  ativo: true,
};

// <input type="datetime-local"> trabalha em horário local, sem fuso.
function paraInputLocal(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const campo = 'w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-brand-orange';
const rotulo = 'block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1';

export default function AdminPack() {
  const [aba, setAba] = useState('conteudo');
  const [itens, setItens] = useState([]);
  const [compras, setCompras] = useState([]);
  const [turmas, setTurmas] = useState([]);
  const [filtroTipo, setFiltroTipo] = useState('');
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');

  const [modal, setModal] = useState(false);
  const [editandoId, setEditandoId] = useState(null);
  const [form, setForm] = useState(FORM_VAZIO);
  const [salvando, setSalvando] = useState(false);

  const carregar = useCallback(async () => {
    setLoading(true);
    setErro('');
    const [itensRes, comprasRes, turmasRes] = await Promise.all([
      supabase.from('pack_itens').select('*, turmas(nome)').order('tipo').order('ordem'),
      supabase
        .from('pack_compras')
        .select('stripe_session_id, valor_centavos, dias, comprado_em, expira_em, profiles(nome)')
        .order('comprado_em', { ascending: false })
        .limit(100),
      supabase.from('turmas').select('id, nome').order('nome'),
    ]);

    if (itensRes.error) setErro(itensRes.error.message);
    setItens(itensRes.data ?? []);
    setCompras(comprasRes.data ?? []);
    setTurmas(turmasRes.data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    carregar();
  }, [carregar]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  const abrirNovo = () => {
    setEditandoId(null);
    setForm(FORM_VAZIO);
    setModal(true);
  };

  const abrirEdicao = (item) => {
    setEditandoId(item.id);
    setForm({
      tipo: item.tipo,
      titulo: item.titulo ?? '',
      descricao: item.descricao ?? '',
      video_url: item.video_url ?? '',
      link_url: item.link_url ?? '',
      data_hora: paraInputLocal(item.data_hora),
      duracao_min: item.duracao_min ?? '',
      turma_id: item.turma_id ?? '',
      ordem: item.ordem ?? 0,
      ativo: item.ativo,
    });
    setModal(true);
  };

  const salvar = async (e) => {
    e.preventDefault();
    if (!form.titulo.trim()) return;
    if (form.tipo === 'live' && !form.data_hora) {
      alert('Informe a data e hora da live.');
      return;
    }

    setSalvando(true);
    const payload = {
      tipo: form.tipo,
      titulo: form.titulo.trim(),
      descricao: form.descricao.trim() || null,
      video_url: form.video_url.trim() || null,
      link_url: form.link_url.trim() || null,
      data_hora: form.tipo === 'live' && form.data_hora ? new Date(form.data_hora).toISOString() : null,
      duracao_min: form.duracao_min ? Number(form.duracao_min) : null,
      turma_id: form.turma_id || null,
      ordem: Number(form.ordem) || 0,
      ativo: form.ativo,
    };

    const { error } = editandoId
      ? await supabase.from('pack_itens').update(payload).eq('id', editandoId)
      : await supabase.from('pack_itens').insert(payload);

    setSalvando(false);
    if (error) {
      alert('Erro ao salvar: ' + error.message);
      return;
    }
    setModal(false);
    carregar();
  };

  const alternarAtivo = async (item) => {
    const { error } = await supabase.from('pack_itens').update({ ativo: !item.ativo }).eq('id', item.id);
    if (error) alert('Erro: ' + error.message);
    else carregar();
  };

  const excluir = async (item) => {
    if (!window.confirm(`Excluir "${item.titulo}"?`)) return;
    const { error } = await supabase.from('pack_itens').delete().eq('id', item.id);
    if (error) alert('Erro ao excluir: ' + error.message);
    else carregar();
  };

  const lista = filtroTipo ? itens.filter((i) => i.tipo === filtroTipo) : itens;
  const fmtData = (iso) => new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
  const fmtValor = (c) => (c == null ? '—' : (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));

  return (
    <div className="flex h-screen bg-[#f4f7f6] font-sans overflow-hidden text-slate-800">
      <AdminSidebar />

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="h-16 bg-white border-b border-slate-200 px-6 md:px-8 flex justify-between items-center shrink-0">
          <div>
            <h2 className="text-lg font-black text-slate-900 leading-tight flex items-center gap-2">
              <Package className="w-5 h-5 text-brand-orange" /> Pack Avulso
            </h2>
            <p className="text-xs font-medium text-slate-500">
              {itens.length} itens de conteúdo · {compras.length} compras recentes
            </p>
          </div>
          {aba === 'conteudo' && (
            <button
              onClick={abrirNovo}
              className="flex items-center gap-2 px-5 py-2.5 bg-brand-orange hover:bg-orange-600 text-white font-bold text-sm rounded-xl transition-all shadow-md cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Novo item
            </button>
          )}
        </header>

        <div className="flex-1 overflow-y-auto p-6 md:p-8">
          <div className="max-w-6xl mx-auto space-y-5">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex p-1 bg-white border border-slate-200 rounded-xl w-fit">
                {[
                  { id: 'conteudo', label: 'Conteúdo', icon: Package },
                  { id: 'compras', label: 'Compras', icon: Receipt },
                ].map(({ id, label, icon: Icon }) => (
                  <button
                    key={id}
                    onClick={() => setAba(id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-colors cursor-pointer ${
                      aba === id ? 'bg-brand-orange text-white' : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    <Icon className="w-4 h-4" /> {label}
                  </button>
                ))}
              </div>

              {aba === 'conteudo' && (
                <select
                  value={filtroTipo}
                  onChange={(e) => setFiltroTipo(e.target.value)}
                  className="bg-white border border-slate-200 rounded-xl py-2.5 px-4 text-sm font-medium text-slate-700 focus:outline-none focus:ring-1 focus:ring-brand-orange"
                >
                  <option value="">Todos os tipos</option>
                  {Object.entries(TIPOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                </select>
              )}
            </div>

            {erro && (
              <div className="bg-red-50 border border-red-200 text-red-600 p-4 rounded-xl text-sm font-medium">
                {erro} — confira se a migration do Pack foi executada.
              </div>
            )}

            {loading ? (
              <div className="flex items-center justify-center py-14 text-slate-400 gap-2">
                <Loader2 className="w-5 h-5 animate-spin" /> Carregando...
              </div>
            ) : aba === 'conteudo' ? (
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-100">
                      {['Item', 'Tipo', 'Turma', 'Data', 'Status', 'Ações'].map((h, i) => (
                        <th key={h} className={`px-6 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider ${i === 5 ? 'text-right' : ''}`}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {lista.map((item) => {
                      const T = TIPOS[item.tipo];
                      return (
                        <tr key={item.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="px-6 py-3.5">
                            <p className="font-bold text-slate-900 text-sm">{item.titulo}</p>
                            <p className="text-xs text-slate-500">Ordem {item.ordem}</p>
                          </td>
                          <td className="px-6 py-3.5 whitespace-nowrap">
                            <span className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-600">
                              <T.icon className="w-4 h-4 text-brand-orange" /> {T.label}
                            </span>
                          </td>
                          <td className="px-6 py-3.5 whitespace-nowrap text-sm font-medium text-slate-600">{item.turmas?.nome || 'Todas'}</td>
                          <td className="px-6 py-3.5 whitespace-nowrap text-sm font-medium text-slate-600">{item.data_hora ? fmtData(item.data_hora) : '—'}</td>
                          <td className="px-6 py-3.5 whitespace-nowrap">
                            <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-bold ${item.ativo ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                              {item.ativo ? 'Publicado' : 'Oculto'}
                            </span>
                          </td>
                          <td className="px-6 py-3.5 whitespace-nowrap text-right">
                            <div className="inline-flex items-center gap-1">
                              <button onClick={() => alternarAtivo(item)} title={item.ativo ? 'Ocultar' : 'Publicar'} className="p-2 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer">
                                {item.ativo ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                              </button>
                              <button onClick={() => abrirEdicao(item)} title="Editar" className="p-2 text-slate-400 hover:text-blue-600 rounded-lg cursor-pointer">
                                <Pencil className="w-4 h-4" />
                              </button>
                              <button onClick={() => excluir(item)} title="Excluir" className="p-2 text-slate-400 hover:text-red-600 rounded-lg cursor-pointer">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                    {lista.length === 0 && (
                      <tr>
                        <td colSpan={6} className="px-6 py-10 text-center text-sm text-slate-400 font-medium">
                          Nenhum item no Pack ainda. Clique em "Novo item" para publicar o aulão, as questões ou uma live.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-100">
                      {['Aluno', 'Valor', 'Comprado em', 'Acesso até'].map((h) => (
                        <th key={h} className="px-6 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {compras.map((c) => {
                      const ativa = new Date(c.expira_em) > new Date();
                      return (
                        <tr key={c.stripe_session_id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="px-6 py-3.5 text-sm font-bold text-slate-900">{c.profiles?.nome || '—'}</td>
                          <td className="px-6 py-3.5 text-sm font-medium text-slate-600">{fmtValor(c.valor_centavos)}</td>
                          <td className="px-6 py-3.5 text-sm font-medium text-slate-600 whitespace-nowrap">{fmtData(c.comprado_em)}</td>
                          <td className="px-6 py-3.5 whitespace-nowrap">
                            <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-bold ${ativa ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                              {fmtData(c.expira_em)} · {ativa ? 'ativo' : 'expirado'}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                    {compras.length === 0 && (
                      <tr>
                        <td colSpan={4} className="px-6 py-10 text-center text-sm text-slate-400 font-medium">
                          Nenhuma compra de Pack ainda.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </main>

      {modal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full max-h-[92vh] overflow-y-auto p-6 md:p-8 shadow-2xl border border-slate-100">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-black text-slate-900">{editandoId ? 'Editar item do Pack' : 'Novo item do Pack'}</h3>
              <button onClick={() => setModal(false)} className="p-2 text-slate-400 hover:text-slate-600 rounded-xl cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={salvar} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className={rotulo}>Tipo *</label>
                  <select value={form.tipo} onChange={set('tipo')} className={campo}>
                    {Object.entries(TIPOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                  </select>
                </div>
                <div>
                  <label className={rotulo}>Turma</label>
                  <select value={form.turma_id} onChange={set('turma_id')} className={campo}>
                    <option value="">Todas as turmas</option>
                    {turmas.map((t) => <option key={t.id} value={t.id}>{t.nome}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className={rotulo}>Título *</label>
                <input required value={form.titulo} onChange={set('titulo')} className={campo} placeholder="Ex: Aulão de Porcentagem — Parte 1" />
              </div>

              <div>
                <label className={rotulo}>Descrição</label>
                <textarea rows={3} value={form.descricao} onChange={set('descricao')} className={campo} />
              </div>

              <div>
                <label className={rotulo}>
                  {form.tipo === 'live' ? 'Link da transmissão (YouTube)' : form.tipo === 'questoes' ? 'Vídeo da resolução (opcional)' : 'Link do vídeo (YouTube / Vimeo)'}
                </label>
                <input value={form.video_url} onChange={set('video_url')} className={campo} placeholder="https://www.youtube.com/watch?v=..." />
              </div>

              {form.tipo !== 'live' && (
                <div>
                  <label className={rotulo}>{form.tipo === 'questoes' ? 'Link da lista de questões (PDF/Drive)' : 'Material de apoio (opcional)'}</label>
                  <input value={form.link_url} onChange={set('link_url')} className={campo} placeholder="https://..." />
                </div>
              )}

              {form.tipo === 'live' && (
                <div>
                  <label className={rotulo}>Data e hora *</label>
                  <input type="datetime-local" value={form.data_hora} onChange={set('data_hora')} className={campo} />
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={rotulo}>Duração (min)</label>
                  <input type="number" min="0" value={form.duracao_min} onChange={set('duracao_min')} className={campo} />
                </div>
                <div>
                  <label className={rotulo}>Ordem</label>
                  <input type="number" value={form.ordem} onChange={set('ordem')} className={campo} />
                </div>
              </div>

              <label className="flex items-center gap-2.5 text-sm font-bold text-slate-700 cursor-pointer">
                <input type="checkbox" checked={form.ativo} onChange={set('ativo')} className="w-4 h-4 accent-orange-500" />
                Publicado (visível para quem comprou o Pack)
              </label>

              <div className="flex gap-3 pt-3">
                <button type="button" onClick={() => setModal(false)} className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition-colors cursor-pointer">
                  Cancelar
                </button>
                <button type="submit" disabled={salvando} className="flex-1 py-3 bg-brand-orange hover:bg-orange-600 text-white rounded-xl font-bold shadow-lg shadow-orange-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60">
                  {salvando && <Loader2 className="w-4 h-4 animate-spin" />} Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
