import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { Loader2, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

const INTERVALO_MS = 2000;
const LIMITE_MS = 30000;

// O Stripe devolve o aluno para cá logo após o pagamento, mas quem libera o acesso
// é o webhook, que pode levar alguns segundos. Aqui consultamos até a assinatura (ou o
// Pack Avulso, quando ?produto=pack) aparecer.
export default function PagamentoSucesso() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const ehPack = searchParams.get('produto') === 'pack';
  const { temAcesso, temPack, recarregarAssinaturas, recarregarPerfil } = useAuth();
  const [expirou, setExpirou] = useState(false);

  const liberado = ehPack ? temPack || temAcesso : temAcesso;
  const destino = ehPack && !temAcesso ? '/pack' : '/dashboard';

  useEffect(() => {
    if (liberado) navigate(destino, { replace: true });
  }, [liberado, destino, navigate]);

  useEffect(() => {
    if (liberado) return undefined;

    const inicio = Date.now();
    const id = setInterval(async () => {
      if (ehPack) await recarregarPerfil();
      else await recarregarAssinaturas();
      if (Date.now() - inicio > LIMITE_MS) {
        clearInterval(id);
        setExpirou(true);
      }
    }, INTERVALO_MS);

    return () => clearInterval(id);
  }, [liberado, ehPack, recarregarAssinaturas, recarregarPerfil]);

  return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6">
      <div className="max-w-md w-full text-center space-y-5">
        {expirou ? (
          <>
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
            <h1 className="text-2xl font-black">Pagamento recebido</h1>
            <p className="text-slate-400 text-sm">
              A confirmação está demorando mais que o normal. Seu acesso será liberado assim que
              o pagamento for processado. Você pode atualizar esta página em alguns minutos.
            </p>
            <div className="flex gap-3 justify-center pt-2">
              <button
                onClick={() => window.location.reload()}
                className="px-5 py-3 bg-brand-orange hover:bg-orange-600 text-white font-bold text-sm rounded-xl cursor-pointer"
              >
                Atualizar
              </button>
              <Link
                to="/"
                className="px-5 py-3 border border-slate-700 text-slate-300 font-bold text-sm rounded-xl"
              >
                Voltar ao início
              </Link>
            </div>
          </>
        ) : (
          <>
            <Loader2 className="w-10 h-10 text-brand-orange mx-auto animate-spin" />
            <h1 className="text-2xl font-black">Confirmando seu pagamento</h1>
            <p className="text-slate-400 text-sm">
              Isso leva só alguns segundos. {ehPack ? 'Você será levado ao seu Pack automaticamente.' : 'Você será levado ao painel automaticamente.'}
            </p>
          </>
        )}
      </div>
    </div>
  );
}
