﻿# Rode na RAIZ do projeto:  powershell -ExecutionPolicy Bypass -File .\verificar-arquivos.ps1
$itens = @(
  @{ p='src\components\PackRoute.jsx'; t='export default' },
  @{ p='src\components\SubscriptionRoute.jsx'; t='export default' },
  @{ p='src\pages\Pack.jsx'; t='export default' },
  @{ p='src\pages\PackExpirado.jsx'; t='export default' },
  @{ p='src\pages\EsqueciSenha.jsx'; t='export default' },
  @{ p='src\pages\RedefinirSenha.jsx'; t='export default' },
  @{ p='src\pages\Pagamento.jsx'; t='export default' },
  @{ p='src\pages\PagamentoSucesso.jsx'; t='export default' },
  @{ p='src\pages\Login.jsx'; t='export default' },
  @{ p='src\pages\Simulados.jsx'; t='export default' },
  @{ p='src\Admin\AdminPack.jsx'; t='export default' },
  @{ p='src\Admin\AdminAlunos.jsx'; t='export default' },
  @{ p='src\Admin\AdminSidebar.jsx'; t='export default' },
  @{ p='src\App.jsx'; t='import PackRoute' },
  @{ p='src\hooks\useAuth.jsx'; t='export function useAuth' },
  @{ p='src\hooks\usePack.js'; t='export function usePackItens' },
  @{ p='src\hooks\useGamificacao.js'; t='ranking_alunos' },
  @{ p='src\lib\packUtils.js'; t='export function formatarUrlEmbed' },
  @{ p='supabase\functions\admin-gerenciar-aluno\index.ts'; t='serve(' },
  @{ p='supabase\functions\criar-checkout-stripe\index.ts'; t='pack_temporario' },
  @{ p='supabase\functions\stripe-webhook\index.ts'; t='registrar_compra_pack' }
)
$falhas = 0
foreach ($i in $itens) {
  if (-not (Test-Path $i.p)) { Write-Host "FALTA      $($i.p)" -ForegroundColor Red; $falhas++; continue }
  if ((Get-Item $i.p).Length -eq 0) { Write-Host "VAZIO      $($i.p)" -ForegroundColor Red; $falhas++; continue }
  if (-not (Select-String -Path $i.p -Pattern $i.t -SimpleMatch -Quiet)) { Write-Host "INCOMPLETO $($i.p) (nao contem: $($i.t))" -ForegroundColor Yellow; $falhas++; continue }
  Write-Host "ok         $($i.p)" -ForegroundColor Green
}
if ($falhas -eq 0) { Write-Host 'Tudo certo.' -ForegroundColor Green } else { Write-Host "$falhas arquivo(s) com problema." -ForegroundColor Red }
