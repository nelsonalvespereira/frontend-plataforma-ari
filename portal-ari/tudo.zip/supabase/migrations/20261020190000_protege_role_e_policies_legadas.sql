-- Fecha duas brechas de administrador. Idempotente. Rode depois das migrations anteriores.
--
-- 1) Havia policies antigas em aulas e questoes que liberam TUDO para quem tem
--    profiles.role = 'admin'. Se a coluna "role" puder ser editada pelo próprio aluno
--    (policy de update do próprio perfil), qualquer aluno viraria admin com um update.
--    a) A trava de colunas passa a proteger também "role".
--    b) As policies antigas saem: usuario_e_admin() já cobre o admin de verdade.

create or replace function public.proteger_colunas_acesso()
returns trigger
language plpgsql
as $$
declare
  v_old jsonb := to_jsonb(old);
  v_new jsonb := to_jsonb(new);
  v_col text;
  v_colunas text[] := array[
    'tipo_acesso', 'data_expiracao_pack', 'acesso_livre', 'is_admin', 'role',
    'turma_id', 'xp', 'dias_seguidos', 'dias_estudados_semana'
  ];
begin
  if current_user in ('authenticated', 'anon') then
    foreach v_col in array v_colunas loop
      if (v_new -> v_col) is distinct from (v_old -> v_col) then
        if not exists (
          select 1 from public.profiles p where p.id = auth.uid() and p.is_admin
        ) then
          raise exception 'Sem permissão para alterar "%".', v_col using errcode = '42501';
        end if;
      end if;
    end loop;
  end if;
  return new;
end;
$$;

drop policy if exists "Admins tem acesso total as aulas" on public.aulas;
drop policy if exists "Admins tem acesso total as questoes" on public.questoes;
