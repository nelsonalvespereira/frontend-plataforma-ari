-- Endurecimento de segurança (idempotente). Rode DEPOIS da migration do Pack.
--
-- 1) O aluno não pode mais editar, pelo navegador, colunas que dão vantagem:
--    turma_id (trocar de turma = ver o conteúdo de outro plano), xp / sequência (ranking),
--    além de tipo_acesso, data_expiracao_pack, acesso_livre e is_admin (já protegidos).
--    Quem muda turma é o admin (Gestão de Alunos) ou o cadastro inicial (trigger do signup).
-- 2) tem_acesso() passa a considerar acesso_livre (cortesia). Hoje o front deixa o aluno de
--    cortesia entrar, mas o banco não: quando as policies de conteúdo exigirem tem_acesso(),
--    ele veria tudo vazio.

create or replace function public.proteger_colunas_acesso()
returns trigger
language plpgsql
as $$
declare
  v_old jsonb := to_jsonb(old);
  v_new jsonb := to_jsonb(new);
  v_col text;
  -- Lista tolerante: se uma coluna não existir, to_jsonb simplesmente não a traz.
  v_colunas text[] := array[
    'tipo_acesso', 'data_expiracao_pack', 'acesso_livre', 'is_admin',
    'turma_id', 'xp', 'dias_seguidos', 'dias_estudados_semana'
  ];
begin
  if current_user in ('authenticated', 'anon') then
    foreach v_col in array v_colunas loop
      if (v_new -> v_col) is distinct from (v_old -> v_col) then
        if not exists (
          select 1 from public.profiles p where p.id = auth.uid() and p.is_admin
        ) then
          raise exception 'Sem permissão para alterar "%".', v_col using errcode = '42501';
        end if;
      end if;
    end loop;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_proteger_colunas_acesso on public.profiles;
create trigger trg_proteger_colunas_acesso
  before update on public.profiles
  for each row execute function public.proteger_colunas_acesso();

create or replace function public.tem_acesso()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and (p.is_admin or p.acesso_livre)
    )
    or exists (
      select 1 from public.assinaturas a
      where a.user_id = auth.uid()
        and a.status in ('active', 'trialing')
    );
$$;

revoke all on function public.tem_acesso() from public;
grant execute on function public.tem_acesso() to authenticated;

-- ---------------------------------------------------------------------------
-- CONFERÊNCIAS MANUAIS (rode e me mande o resultado; não alteram nada):
--
-- a) Quem lê conteúdo pago hoje? (se aparecer "true"/"auth.uid() is not null" nas tabelas
--    questoes, aulas, simulados, simulado_questoes, modulos, lives, o conteúdo está aberto
--    para qualquer logado, mesmo sem assinatura):
--      select tablename, policyname, cmd, qual from pg_policies
--      where schemaname = 'public'
--        and tablename in ('questoes','aulas','simulados','simulado_questoes','modulos','lives')
--      order by 1, 2;
--
-- b) A função admin_mudar_senha_usuario (usada antes pela tela de alunos) permite que
--    QUALQUER aluno troque a senha de qualquer pessoa? Veja o corpo:
--      select pg_get_functiondef('public.admin_mudar_senha_usuario(uuid, text)'::regprocedure);
--    Se ela não checar is_admin dentro, apague:
--      drop function public.admin_mudar_senha_usuario(uuid, text);
--    (a tela agora usa a Edge Function admin-gerenciar-aluno, que não depende dela).
-- ---------------------------------------------------------------------------
