-- Ranking que funciona com a RLS atual.
-- Problema: o aluno só enxerga o PRÓPRIO profile ("profiles: select proprio"), então o ranking
-- (um select em profiles) devolvia só ele mesmo. Esta função security definer devolve apenas
-- o mínimo necessário: id, primeiro nome e XP. Nada de e-mail, plano ou datas.
--   p_turma_id preenchido  -> ranking da turma (só vale para a turma do próprio aluno)
--   p_turma_id nulo        -> ranking geral (todas as turmas)
-- Só responde para quem tem acesso (assinante, pack ativo, admin ou cortesia).

create or replace function public.ranking_alunos(p_turma_id uuid default null, p_limite integer default 50)
returns table (id uuid, nome text, xp integer)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if auth.uid() is null or not public.pode_ver_pack() then
    return; -- sem acesso: lista vazia
  end if;

  -- Ranking de turma só da turma do próprio aluno (admin pode ver qualquer uma).
  if p_turma_id is not null
     and p_turma_id is distinct from (select p.turma_id from public.profiles p where p.id = auth.uid())
     and not exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin) then
    return;
  end if;

  return query
    select p.id,
           coalesce(nullif(split_part(trim(p.nome), ' ', 1), ''), 'Aluno')::text,
           coalesce(p.xp, 0)::integer
      from public.profiles p
     where not coalesce(p.is_admin, false)
       and (p_turma_id is null or p.turma_id = p_turma_id)
     order by coalesce(p.xp, 0) desc, p.created_at asc
     limit least(greatest(coalesce(p_limite, 50), 1), 200);
end;
$$;

revoke all on function public.ranking_alunos(uuid, integer) from public, anon;
grant execute on function public.ranking_alunos(uuid, integer) to authenticated;
