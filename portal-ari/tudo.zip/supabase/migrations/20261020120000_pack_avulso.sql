-- Pack Avulso (Aulão + Q&A + Lives com acesso temporário).
-- Idempotente: pode rodar mais de uma vez. Rode DEPOIS da migration de assinaturas
-- (usa public.tem_acesso()).
--
-- Resumo do desenho:
--   * profiles.tipo_acesso / data_expiracao_pack  -> estado do acesso temporário
--   * planos.tipo / duracao_dias                  -> um plano pode ser 'assinatura' ou 'pack'
--   * pack_compras                                -> uma linha por compra (idempotência + auditoria)
--   * pack_itens                                  -> conteúdo do Pack (aulão, questões, lives)
--   * registrar_compra_pack()                     -> chamada SÓ pelo webhook (service role)
--   * revogar_pack_expirado() / expirar_packs()   -> revogação automática
--   * RLS usa o relógio do BANCO: mesmo que o front esteja desatualizado, expirou = sem dados.

-- =========================================================== profiles
-- Se tipo_acesso / data_expiracao_pack já existirem (default atual: 'assinante'), são mantidas.
alter table public.profiles
  add column if not exists tipo_acesso text not null default 'regular',
  add column if not exists data_expiracao_pack timestamptz;

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'profiles_tipo_acesso_check'
  ) then
    alter table public.profiles
      add constraint profiles_tipo_acesso_check
      check (tipo_acesso in ('assinante', 'regular', 'pack_temporario', 'pack_expirado'))
      not valid;  -- vale para escritas novas; não reclama de linhas antigas
  end if;
end $$;

create index if not exists profiles_pack_ativo_idx
  on public.profiles (data_expiracao_pack)
  where tipo_acesso = 'pack_temporario';

-- ---------------------------------------------------------------------------
-- Trava: o aluno NÃO pode editar as próprias colunas de acesso pelo navegador.
-- (profiles costuma ter policy "update do próprio registro"; sem esta trava, qualquer
-- aluno poderia se dar um pack eterno com um update no console.)
-- Passam: service role (webhook), funções security definer (current_user = dono),
-- SQL Editor/cron (postgres) e administradores.
-- ---------------------------------------------------------------------------
create or replace function public.proteger_colunas_acesso()
returns trigger
language plpgsql
as $$
begin
  if current_user in ('authenticated', 'anon') then
    if (new.tipo_acesso is distinct from old.tipo_acesso)
       or (new.data_expiracao_pack is distinct from old.data_expiracao_pack)
       or (new.acesso_livre is distinct from old.acesso_livre)
       or (new.is_admin is distinct from old.is_admin) then
      if not exists (
        select 1 from public.profiles p where p.id = auth.uid() and p.is_admin
      ) then
        raise exception 'Sem permissão para alterar dados de acesso.' using errcode = '42501';
      end if;
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_proteger_colunas_acesso on public.profiles;
create trigger trg_proteger_colunas_acesso
  before update on public.profiles
  for each row execute function public.proteger_colunas_acesso();

-- ============================================================== planos
-- Um plano pode ser assinatura mensal (padrão) ou pack avulso (pagamento único).
alter table public.planos
  add column if not exists tipo text not null default 'assinatura',
  add column if not exists duracao_dias integer;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'planos_tipo_check') then
    alter table public.planos
      add constraint planos_tipo_check check (tipo in ('assinatura', 'pack'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'planos_pack_duracao_check') then
    alter table public.planos
      add constraint planos_pack_duracao_check
      check (tipo <> 'pack' or (duracao_dias between 1 and 365));
  end if;
end $$;

-- >>> CADASTRE O PACK (troque o price_id pelo preço AVULSO / pagamento único do Stripe):
--
--   insert into public.planos (price_id, nome, descricao, valor_centavos, ordem, tipo, duracao_dias)
--   values ('price_XXXXXXXX', 'Pack Aulão + Q&A',
--           'Aulão ao vivo, Q&A e lives exclusivas com acesso por 48 horas.',
--           1990, 10, 'pack', 2)
--   on conflict (price_id) do update
--     set tipo = 'pack', duracao_dias = excluded.duracao_dias, nome = excluded.nome,
--         descricao = excluded.descricao, valor_centavos = excluded.valor_centavos;
--
-- ATENÇÃO: no Stripe o preço do pack precisa ser "Pagamento único" (one-time).
-- Preço recorrente não funciona em mode = 'payment'.

-- =========================================================== pack_compras
create table if not exists public.pack_compras (
  stripe_session_id  text primary key,                -- cs_... (garante 1 compra = 1 efeito)
  user_id            uuid not null references public.profiles (id) on delete cascade,
  price_id           text,
  stripe_payment_intent text,
  valor_centavos     integer,
  dias               integer not null,
  comprado_em        timestamptz not null,
  expira_em          timestamptz not null,
  created_at         timestamptz not null default now()
);

create index if not exists pack_compras_user_idx on public.pack_compras (user_id, comprado_em desc);

alter table public.pack_compras enable row level security;

drop policy if exists "pack_compras_leitura" on public.pack_compras;
create policy "pack_compras_leitura" on public.pack_compras
  for select to authenticated
  using (
    user_id = auth.uid()
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin)
  );
-- Sem policies de escrita: só a service role (webhook) escreve.

-- ===================================================== registrar_compra_pack
-- Atômica e idempotente. Se o Stripe reenviar o evento (mesma sessão), não estende de novo.
-- Se o aluno comprar de novo com o pack ainda ativo, SOMA os dias ao fim atual.
create or replace function public.registrar_compra_pack(
  p_session_id     text,
  p_user_id        uuid,
  p_price_id       text,
  p_dias           integer,
  p_valor_centavos integer,
  p_payment_intent text,
  p_comprado_em    timestamptz
)
returns timestamptz
language plpgsql
security definer
set search_path = public
as $$
declare
  v_base     timestamptz;
  v_expira   timestamptz;
  v_inserido text;
begin
  if p_dias is null or p_dias < 1 or p_dias > 365 then
    raise exception 'Duração inválida para o pack: %', p_dias;
  end if;

  -- Trava a linha do perfil: duas compras simultâneas não se atropelam.
  select case
           when tipo_acesso = 'pack_temporario' and data_expiracao_pack > p_comprado_em
             then data_expiracao_pack
           else p_comprado_em
         end
    into v_base
    from public.profiles
   where id = p_user_id
     for update;

  if not found then
    raise exception 'Perfil % não encontrado', p_user_id;
  end if;

  v_expira := v_base + make_interval(days => p_dias);

  insert into public.pack_compras
    (stripe_session_id, user_id, price_id, stripe_payment_intent, valor_centavos, dias, comprado_em, expira_em)
  values
    (p_session_id, p_user_id, p_price_id, p_payment_intent, p_valor_centavos, p_dias, p_comprado_em, v_expira)
  on conflict (stripe_session_id) do nothing
  returning stripe_session_id into v_inserido;

  if v_inserido is null then
    -- Já processada antes: devolve a expiração que foi gravada, sem alterar nada.
    select expira_em into v_expira from public.pack_compras where stripe_session_id = p_session_id;
    return v_expira;
  end if;

  update public.profiles
     set tipo_acesso = 'pack_temporario',
         data_expiracao_pack = v_expira
   where id = p_user_id;

  return v_expira;
end;
$$;

revoke all on function public.registrar_compra_pack(text, uuid, text, integer, integer, text, timestamptz) from public, anon, authenticated;
grant execute on function public.registrar_compra_pack(text, uuid, text, integer, integer, text, timestamptz) to service_role;

-- ================================================================ expiração
-- Chamada pelo front quando o contador chega a zero. Só mexe no PRÓPRIO perfil e
-- só se o relógio do banco confirmar que expirou (o relógio do navegador não vale nada).
create or replace function public.revogar_pack_expirado()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_linhas integer;
begin
  update public.profiles
     set tipo_acesso = 'pack_expirado'
   where id = auth.uid()
     and tipo_acesso = 'pack_temporario'
     and (data_expiracao_pack is null or data_expiracao_pack <= now());
  get diagnostics v_linhas = row_count;
  return v_linhas > 0;
end;
$$;

revoke all on function public.revogar_pack_expirado() from public, anon;
grant execute on function public.revogar_pack_expirado() to authenticated;

-- Varredura geral (para quem não voltou ao site): marca todos os packs vencidos.
create or replace function public.expirar_packs()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_linhas integer;
begin
  update public.profiles
     set tipo_acesso = 'pack_expirado'
   where tipo_acesso = 'pack_temporario'
     and (data_expiracao_pack is null or data_expiracao_pack <= now());
  get diagnostics v_linhas = row_count;
  return v_linhas;
end;
$$;

revoke all on function public.expirar_packs() from public, anon, authenticated;
grant execute on function public.expirar_packs() to service_role;

-- Agenda a varredura a cada 15 min, se o pg_cron estiver disponível.
-- (Se der aviso, ative em Database > Extensions > pg_cron e rode este bloco de novo.)
do $$
begin
  create extension if not exists pg_cron;
  perform cron.schedule('expirar-packs', '*/15 * * * *', 'select public.expirar_packs()');
exception when others then
  raise notice 'pg_cron indisponível (%). A revogação continua funcionando pelo front e pela RLS.', sqlerrm;
end $$;

-- ====================================================== pode_ver_pack (RLS)
-- true se: admin, assinante (tem_acesso), acesso livre OU pack temporário ainda dentro do prazo.
create or replace function public.pode_ver_pack()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select
    public.tem_acesso()
    or exists (
      select 1 from public.profiles p
      where p.id = auth.uid()
        and (
          p.acesso_livre
          or (p.tipo_acesso = 'pack_temporario' and p.data_expiracao_pack > now())
        )
    );
$$;

revoke all on function public.pode_ver_pack() from public, anon;
grant execute on function public.pode_ver_pack() to authenticated;

-- =========================================================== pack_itens
create table if not exists public.pack_itens (
  id           uuid primary key default gen_random_uuid(),
  tipo         text not null check (tipo in ('aulao', 'questoes', 'live')),
  titulo       text not null,
  descricao    text,
  video_url    text,                 -- aulão: vídeo; questões: resolução em vídeo; live: link da transmissão
  link_url     text,                 -- questões: PDF/caderno/lista (Drive, etc.)
  data_hora    timestamptz,          -- lives: início
  duracao_min  integer,
  turma_id     uuid references public.turmas (id) on delete set null,  -- null = vale para todas
  ordem        integer not null default 0,
  ativo        boolean not null default true,
  created_at   timestamptz not null default now()
);

create index if not exists pack_itens_tipo_idx on public.pack_itens (tipo, ordem);

alter table public.pack_itens enable row level security;

drop policy if exists "pack_itens_leitura" on public.pack_itens;
create policy "pack_itens_leitura" on public.pack_itens
  for select to authenticated
  using (ativo and public.pode_ver_pack());

drop policy if exists "pack_itens_admin" on public.pack_itens;
create policy "pack_itens_admin" on public.pack_itens
  for all to authenticated
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin))
  with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));
